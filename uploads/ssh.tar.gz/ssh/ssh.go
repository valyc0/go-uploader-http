package main

import (
    "flag"
    "fmt"
    "io"
    "io/ioutil"
    "log"
    "net"
    "os"

    "golang.org/x/crypto/ssh"
)

type ForwardedTCPIPRequest struct {
    Address   string // L'indirizzo a cui ci si sta connettendo
    Port      uint32 // La porta a cui ci si sta connettendo
    OriginAddr string // L'indirizzo del client che sta inoltrando
    OriginPort uint32 // La porta del client che sta inoltrando
}

func main() {
    // Definisci la flag per la porta
    port := flag.Int("port", 2222, "Porta sulla quale il server SSH ascolta")
    flag.Parse()

    // Verifica se il file della chiave privata esiste
    if _, err := os.Stat("id_rsa"); os.IsNotExist(err) {
        log.Fatal("File id_rsa non trovato. Genera una chiave con: ssh-keygen -t rsa -f id_rsa -N \"\"")
    }

    privateBytes, err := ioutil.ReadFile("id_rsa")
    if err != nil {
        log.Fatalf("Impossibile leggere il file della chiave privata: %v", err)
    }

    private, err := ssh.ParsePrivateKey(privateBytes)
    if err != nil {
        log.Fatalf("Impossibile analizzare la chiave privata: %v", err)
    }

    config := &ssh.ServerConfig{
        PasswordCallback: func(c ssh.ConnMetadata, pass []byte) (*ssh.Permissions, error) {
            if c.User() == "test" && string(pass) == "password" {
                return nil, nil
            }
            return nil, fmt.Errorf("password rifiutata per %q", c.User())
        },
    }

    config.AddHostKey(private)

    // Crea l'ascoltatore sulla porta specificata
    listener, err := net.Listen("tcp", fmt.Sprintf("0.0.0.0:%d", *port))
    if err != nil {
        log.Fatalf("Impossibile ascoltare sulla porta %d: %v", *port, err)
    }
    fmt.Printf("In ascolto su 0.0.0.0:%d...\n", *port)

    for {
        nConn, err := listener.Accept()
        if err != nil {
            log.Printf("Impossibile accettare la connessione in arrivo: %v", err)
            continue
        }

        go handleConnection(nConn, config)
    }
}

func handleConnection(nConn net.Conn, config *ssh.ServerConfig) {
    defer nConn.Close()

    conn, chans, reqs, err := ssh.NewServerConn(nConn, config)
    if err != nil {
        log.Printf("Handshake fallito: %v", err)
        return
    }
    defer conn.Close()

    log.Printf("Nuova connessione SSH da %s (%s)", conn.RemoteAddr(), conn.ClientVersion())

    go ssh.DiscardRequests(reqs)

    for newChannel := range chans {
        if newChannel.ChannelType() == "session" {
            channel, requests, err := newChannel.Accept()
            if err != nil {
                log.Printf("Impossibile accettare il canale: %v", err)
                return
            }

            go handleSessionChannel(channel, requests)
        } else if newChannel.ChannelType() == "forwarded-tcpip" {
            channel, requests, err := newChannel.Accept()
            if err != nil {
                log.Printf("Impossibile accettare il canale di forwarding: %v", err)
                return
            }

            go handleForwardedTCPIPChannel(channel, requests)
        } else {
            newChannel.Reject(ssh.UnknownChannelType, "tipo di canale sconosciuto")
        }
    }
}

func handleSessionChannel(channel ssh.Channel, requests <-chan *ssh.Request) {
    defer channel.Close()
    for req := range requests {
        switch req.Type {
        case "shell":
            channel.Write([]byte("Benvenuto nel server SSH Go!\n"))
            req.Reply(true, nil)
        case "exec":
            channel.Write([]byte("L'esecuzione dei comandi non è supportata.\n"))
            req.Reply(true, nil)
        default:
            log.Printf("Richiesta non gestita di tipo: %s", req.Type)
        }
    }
}

func handleForwardedTCPIPChannel(channel ssh.Channel, requests <-chan *ssh.Request) {
    defer channel.Close()

    req := <-requests
    if req.Type != "forwarded-tcpip" {
        log.Printf("Richiesta non valida: %s", req.Type)
        return
    }

    // Estrarre le informazioni dalla richiesta di forwarding
    addr := string(req.Payload[0:4])    // Indirizzo di destinazione
    port := uint32(req.Payload[4:8][0]) // Porta di destinazione
    originAddr := string(req.Payload[8:12]) // Indirizzo di origine
    originPort := uint32(req.Payload[12:16][0]) // Porta di origine

    fmt.Printf("Forwarding da %s:%d a %s:%d\n", originAddr, originPort, addr, port)

    req.Reply(true, nil)

    go func() {
        // Connessione al servizio remoto
        conn, err := net.Dial("tcp", fmt.Sprintf("%s:%d", addr, port))
        if err != nil {
            log.Printf("Impossibile connettersi a %s:%d: %v", addr, port)
            return
        }
        defer conn.Close()

        // Copia i dati tra il canale e la connessione
        go io.Copy(channel, conn)
        io.Copy(conn, channel)
    }()
}
